package kcp.spring.sevice;

import kcp.spring.dto.StudentDTO;

public interface StudentService {
    	public String studentRegister(StudentDTO dto) throws Exception;
}
