package kcp.spring.vo;

import lombok.Data;

@Data
public class StudentVO {

	private String sName, sAddress, sRollno;
	private String mark1, mark2, mark3, mark4;
}
