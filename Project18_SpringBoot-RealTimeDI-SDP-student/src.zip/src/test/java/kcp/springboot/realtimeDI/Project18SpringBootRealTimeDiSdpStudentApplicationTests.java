package kcp.springboot.realtimeDI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project18SpringBootRealTimeDiSdpStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
