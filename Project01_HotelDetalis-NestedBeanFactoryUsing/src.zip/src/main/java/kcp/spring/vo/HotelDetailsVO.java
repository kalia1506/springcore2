package kcp.spring.vo;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@ToString
public class HotelDetailsVO {
	 private String city,state,preNight, ratting; 
	    private String hname, roomType,area;
}
